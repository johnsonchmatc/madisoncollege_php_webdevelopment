<?php

/* ===============================
== Basic PHP/MySQL Authentication 
== by x0x 
== Email: x0x@ukshells.co.uk
================================*/

$CONFIG                  = array();
$CONFIG['HOST_NAME']     = 'localhost';
$CONFIG['DATABASE_NAME'] = 'phplogin';
$CONFIG['DB_USERNAME']   = 'root';
$CONFIG['DB_PASSWORD']   = '';
?>