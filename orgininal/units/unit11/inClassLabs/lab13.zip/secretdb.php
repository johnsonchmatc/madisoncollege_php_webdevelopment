<?php
  $name = $_POST['name'];
  $password = $_POST['password']; 

  if(!isset($_POST['name'])&&!isset($_POST['password']))
  {
    //Visitor needs to enter a name and password
?>
    <h1>Please Log In</h1>
    This page is secret.
    <form method="post" action="secretdb.php">
    <table border="1">
    <tr>
      <th> Username </th>
      <td> <input type="text" name="name"> </td>
    </tr>
    <tr>
      <th> Password </th>
      <td> <input type="password" name="password"> </td>
    </tr>
    <tr>
      <td colspan="2" align="center">
        <input type="submit" value="Log In">
      </td>
    </tr>
    </table>
    </form>
<?php
  }
  else
  {
    // connect to mysql
    $mysql = mysqli_connect( '198.150.221.247', 'astudent', 'php155' );
    if(!$mysql)
    {
      echo 'Cannot connect to database.';
      exit;
    }
    // select the appropriate database
    $selected = mysqli_select_db( $mysql, 'astudent' );
    if(!$selected)
    {
      echo 'Cannot select database.';
      exit;
    }

    // query the database to see if there is a record which matches
    $query = "select count(*) from authorized_users where
              name = '$name' and
              password = '$password'";

    $result = mysqli_query( $mysql, $query );
    if(!$result)
    {
      echo 'Cannot run query.';
      exit;
    }
    $row = mysqli_fetch_row( $result );
    $count = $row[0];
    
    if ( $count > 0 )
    {
      // visitor's name and password combination are correct
      echo '<h1>Here it is!</h1>';
      echo 'I bet you are glad you can see this secret page.';
    }
    else
    {
      // visitor's name and password combination are not correct
      echo '<h1>Go Away!</h1>';
      echo 'You are not authorized to view this resource.';
    }
  }
?>