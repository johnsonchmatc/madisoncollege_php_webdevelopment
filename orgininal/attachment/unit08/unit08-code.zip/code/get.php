<html>
 <head>
  <title>Processing Form</title>
 </head>
 <body>
  <?php
    // Medium style; use superglobal array
    $name = $_GET['your_name'];
    $phone = $_GET['your_phone'];
    $email = $_GET['your_email_addr'];
  ?>
  <div align="center">
   <table>
    <tr><td><font face="verdana" size="+1" color="#000066">
    Welcome to PHP, <em><?= $name ?>.</em>
    </td></tr>
    <tr><td><font face="verdana" size="+1" color="#000066">
    Can I call you at <em><?=$phone ?>? </em>
    </td></tr>
    <tr><td><font face="verdana" size="+1" color="#000066">
    Is it ok to send you email at <em><?=$email ?>?</em>
    </td></tr>
   </table>
  </div>
 </body>
</html>
