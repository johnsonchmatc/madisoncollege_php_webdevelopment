<html>
 <head>
  <title>Server Information</title>
 </head>
 <body bgcolor="yellow">
  <table border="1">
  <?php
    foreach($_SERVER as $key=>$value) {
      echo '<tr>';
      echo "<td><b>$key</td><td>$value</td>";
      echo '</tr>';
    }
  ?>
  </table>
 </body>
</html>
