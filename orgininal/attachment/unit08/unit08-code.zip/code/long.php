<html>
 <head>
  <title>Processing w Old Arrays</title>
 </head>
 <body bgcolor = "lightgreen"><font size="+1">
  <h2>Here is the form input:</h2>
  <?php
    // Long style with GET method
    $name = $HTTP_GET_VARS['name'];
    $phone = $HTTP_GET_VARS['phone'];
    $email = $HTTP_GET_VARS['email_addr'];
    print "Welcome to PHP $name<br />";
    print "Can I call you at $phone<br />";
    print "Is it OK to send you email at $email<br />";
  ?>
 </body>
</html>
