<?php
  $handle = fopen($_FILES['user_file']['tmp_name'],'r');
  while(!feof($handle)) {
    $text = fgets($handle);
    echo $text,'<br />';
  }
?>
