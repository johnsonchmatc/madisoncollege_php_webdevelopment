<?php
  // Display information about PHP environment
  phpinfo(16);
?>
