<?php
  foreach ($_REQUEST as $key => $value) {
    echo "Input field name = <b>$key</b><br />";
    echo "Input field value = <b>$value</b><br /><br />";
  }
?>
