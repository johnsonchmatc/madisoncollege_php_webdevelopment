<?php
  // Wrong!
  echo "<p>You are going to be redirected to a new page!</p>";
  header("Location: http://www.ellieq.com");
?>
