<html>
 <head>
  <title>Processing Form</title>
 </head>
 <body bgcolor = "lightgreen"><font size="+1">
  <h2>Here is the form input:</h2>
  <?php
    extract($_REQUEST); // Get the form input
    print "Welcome to PHP $name<br />";
    print "Can I call you at $phone<br />";
    print "Is it ok to send you email at $email<br />";
  ?>
 </body>
</html>
