<?php
  # PHP 5 Constructor
  class House{
    function __construct() {
      print "Constructor initializing a new house.<br>\n";
    }
  } /* End class definition */

  $my_house= new House;
  $your_house = new House;
?>
