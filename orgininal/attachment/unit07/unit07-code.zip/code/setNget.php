<?php
  // Using the set and get methods
  class Employee {
    private $name;  // Properties
    protected $address;
    public $phone;
    // public magic methods
    function __set($property,$value) // setter
    {
      $this->property = $value;
    }
    function __get($property) // getter
    {
      return $this->property;
    }
  };

  // Create objects of the class
  $Heidi = new Employee();
  $Heidi->name = "Heidi Clum";
  echo $Heidi->name, "<br>\n";
  $Heidi->address = "1234 Somewhere Blvd ";
  echo $Heidi->address, "<br>\n";
  $Heidi->phone ="123-456-7890";
  echo $Heidi->phone,"<br>\n";
  echo "<hr>";
  
  $Brad = new Employee();
  $Brad->name = "Brad Bit";
  echo $Brad->name, "<br>\n";
  $Brad->address = "4321 Sunset Blvd ";
  echo $Brad->address, "<br>\n";
  $Brad->phone = "987-654-3210";
  echo $Brad->phone, "<br>\n";
?>
