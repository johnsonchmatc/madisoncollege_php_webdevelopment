<?php
  class Computer {
    private $serial_number;
    final function setSerialNumber($serial_number) {
      $this->serial_number = $serial_number;
    }
  }
  
  class Laptop extends Computer {
    private $new_serial_number;
    function setSerialNumber() {
      $this->new_serial_number=$new_serial_number;
    }
  }
  
  $portable->new Laptop();
  $portable -> setSerialNumber("abc!@$#");
?>
