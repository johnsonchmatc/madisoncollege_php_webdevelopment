<br><br>
<table width="100%" bgcolor="#ffffcc">
<tr>
<td width="33%"><div align="left">Madison WI</div></td>
<td width="34%"><div align="center">February 2008</div></td>
<td width="33%"><div align="right">www.GuestBook.org</div></td>
</tr>
</table><br><br>
</tr>
</table>
</body>
</html>
