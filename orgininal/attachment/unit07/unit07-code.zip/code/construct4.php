<?php
  # PHP 4 Constructor
  class House{
    function House() {
      print "Constructor initializing a new house.<br>\n";
    }
  } /* End class definition */

  $my_house= new House;
  $your_house=new House;
?>
