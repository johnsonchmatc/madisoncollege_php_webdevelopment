<html>
 <head>
  <title>Sorting an Array</title>
 </head>
 <body bgcolor="CCFFFF">
  <h3>Sorting an Array Alphabetically</h3>
  <font size="+1">
  <pre><b>
  <?php
    $animals = array("dog","cat","horse","monkey",
                     "gorilla","zebra");
    sort($animals);
    print_r($animals);
  ?>
  </b></pre>
 </body>
</html>
