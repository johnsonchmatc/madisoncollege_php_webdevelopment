<html>
 <head>
  <title>Array of Colors</title>
 </head>
 <body bgcolor="lightgreen">
  <?php
    // PHP assigns keys starting at 0
    $colors = array('red','green','blue');
    echo "<b>\$colors is $colors.<br />";
    // Accessing array elements
    echo "\$colors[0] is $colors[0].<br />";
    echo "\$colors[1] is $colors[1].<br />";
    echo "\$colors[2] is $colors[2].<br />";
    $colors[] = 'yellow';   // Let's add another element
    echo "\$colors[3] is $colors[3].<br />";
    echo "<hr>";
    // Start a new $colors array
    $colors = array(1=>'purple', 2=>'orange');
    $colors[] = 'yellow';
    echo "\$colors[1] is $colors[1].<br />";
    echo "\$colors[2] is $colors[2].<br />";
    echo "\$colors[3] is $colors[3].<br />";
  ?>
 </body>
</html>
