<html>
 <head>
  <title>The count() function</title>
 </head>
 <body bgcolor="lightgreen">
 <h3>The count() function</h3>
  <?php
    $colors = array('red','green','blue');
    $colors[] = 'yellow';
    $size = count($colors);
    echo "The size of the array is $size.<br />";
    echo "<hr>";
  ?>
 </body>
</html>
