<html>
 <head>
  <title>Array of Arrays</title>
 </head>
 <body>
  <h3>Array of Arrays</h3>
  <font face="arial">
  <?php
    $numbers = array(array(10,12,14,16),
                     array(15,18,21,24),
                     array(20,25,30,35)
                    );
    echo "<table border='1'><caption><font size='-2'>Rows and
          Columns</font></caption>";
    for($i=0; $i < 3; $i++) { // 3 rows
      echo "<tr bgcolor='999FFF'>";
      for($j=0; $j<4; $j++){ // 4 columns
        echo "<td><b>". $numbers[$i][$j];
      }
      echo "</td></tr>";
    }
    echo "</table>";
  ?>
 </body>
</html>
