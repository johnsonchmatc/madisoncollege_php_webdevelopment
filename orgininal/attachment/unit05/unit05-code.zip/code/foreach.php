<html>
 <head>
  <title>The foreach Loop</title>
 </head>
 <body bgcolor="lightgreen">
  <h3>The foreach Loop</h3>
  <b>
  <?php
    $colors=array('red','green','blue','yellow');
    $employee = array('Name' => 'Jon Doe',
                      'ID' => '23d4',
                      'Job Title'=> 'Designer',
                      'Department'=>'Web Development'
                     );
    // simple array
    foreach($colors as $value) {
      echo "$value <br />";
    }
    echo "<hr>";
    // Associative array
    foreach($employee as $key => $value) {
      echo "employee[$key] => $value<br />";
       }
  ?>
  </b>
 </body>
</html>
