<html>
 <head>
  <title>The var_dump() Function</title>
 </head>
 <body bgcolor="CCFF99">
  <h3>The var_dump() Function</h3>
  <pre><b>
  <?php
    $colors = array('red','green','blue','yellow');
    $book=array('Title'=>'War and Peace',
                'Author'=>'Tolstoy',
                'Publisher'=>'Oxford University Press'
               );
    var_dump($colors);
    echo '<hr>';
    var_dump($book);
  ?>
  </b></pre>
 </body>
</html>
