<html>
 <head>
  <title>Sorting an Array</title>
 </head>
 <body bgcolor="CCFFFF">
  <font style="arial" size="+1">
  <table border="2" cellspacing="3">
   <caption>Reverse Sort by Values</caption>
   <tr><td>
   <?php
     $states = array("HI"=>"Hawaii",
                     "ME"=>"Maine",
                     "MT"=>"Montana",
                     "CA"=>"California",
                     "AZ"=>"Arizona",
                     "MD"=>"Maryland",
                    );
     arsort($states);
     while(list($key, $val) = each($states)) {
       echo "states[". $key ."] => "."<b>$val</b>\n<br />";
     }
   ?>
   </td></tr>
  </table>
 </body>
</html>
