<html>
 <head>
  <title>Sorting an Array</title>
 </head>
 <body bgcolor="CCFFFF">
 <h3>Sorting an Array Numerically</h3>
  <font size="+1">
  <pre><b>
  <?php
      $animals = array("5 dogs","15 cats","10 horses","1 monkey",
                       "1 gorilla","2 zebras");
      sort($animals, SORT_NUMERIC);
      print_r($animals);
  ?>
  </b></pre>
 </body>
</html>
