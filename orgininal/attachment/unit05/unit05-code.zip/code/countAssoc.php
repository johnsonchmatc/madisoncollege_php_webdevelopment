<html>
 <head>
  <title>Counting Elements in a Multidimensional Array
  </title>
 </head>
 <body bgcolor="blue">
  <h3>Counting Elements in a Multidimensional Array
  </h3>
  <div align="center">
  <table border="2">
  <tr><td bgcolor="cornflowerblue">
  <?php
    $plants = array('perennials' => array('Day Lilies',
                                          'Coral Bells',
                                          'Goldenrod',
                                          'Russian Sage'),
                    'annuals' => array('Begonia',
                                       'Sweet Alyssum',
                                       'Cosmos',
                                       'Helioptrope')
                   );
    // Recursive count
    echo "The number of elements: ",
          count($plants, COUNT_RECURSIVE),"\n<br />";
    echo "The number of arrays: ", count($plants),
         "\n<br />";
  ?>
  </td></tr>
  </table>
 </body>
</html>
