<html>
 <head>
  <title>The array_values() Function</title>
 </head>
 <body bgcolor="silver">
  <h3>The array_values() Function</h3>
  <b><pre>
  <?php
    $colors=array("red","green","blue","yellow");
    print "The original array:<br />";
    $values = array_values($colors);
    print_r($colors);
    print "The values:<br />";
    print_r($values);
  ?>
  <hr>
  <?php
    $poem = array("Title"=>"The Raven","Author"=>"Edgar Allen Poe");
    $values = array_values($poem);
    print "The original array:<br />";
    print_r($poem);
    print "The values:<br />";
    print_r($values);
  ?>
  </pre></b>
 </body>
</html>
