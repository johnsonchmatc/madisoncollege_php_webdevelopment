<html>
 <head>
  <title>Array of Colors</title>
 </head>
 <body bgcolor="lightgreen">
  <pre>
  <?php
    $colors = array("red","blue","green","red",
                    "yellow","red","blue");
    $unique_count = array_count_values($colors);
    print_r($unique_count);
  ?>
  </pre>
 </body>
</html>
