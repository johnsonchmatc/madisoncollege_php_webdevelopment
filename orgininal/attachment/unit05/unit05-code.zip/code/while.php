<html>
 <head>
  <title>The while Loop</title>
 </head>
 <body bgcolor="lightgreen">
  <h3>The while Loop</h3>
  <table border='1' bordercolor='black' bgcolor='yellow'>
  <caption>Elements</caption>
  <?php
    $colors=array('red','white','aqua','yellow');
    $i = 0;
    while($i < count($colors)) {
      echo "<tr bgcolor=$colors[$i]><td><b>$colors[$i]
            </b></td></tr>";
      $i++;
    }
  ?>
  </table>
 </body>
</html>
