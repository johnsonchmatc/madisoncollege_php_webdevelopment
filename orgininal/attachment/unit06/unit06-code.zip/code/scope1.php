<?php
  // Global variable, visible outside functions
  $friend = "Sam";
  
  function who() {
    // Local variable; disappears when function ends
    $friend = "Joe"; 
    print "In the function $friend is your local friend.<br />";
  }
  
  who();   // Function call
  print "Out of the function, your friend is $friend.<br.>";
?>
