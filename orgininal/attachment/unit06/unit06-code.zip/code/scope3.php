<html>
 <head>
  <title>Function Arguments</title>
 </head>
 <body bgcolor="lightblue">
  <font size="+1" face="arial">
  <?php
    function raise_sal() {
      $GLOBALS['salary'] *= 1.1;
    }
    $salary = 50000;
    raise_sal();
    echo 'Congratulations! Your new salary is: $'. $salary .'<br />';
  ?>
 </body>
</html>
