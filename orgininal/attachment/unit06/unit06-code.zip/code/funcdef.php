<html>
 <head>
  <title>A Simple Function</title>
 </head>
 <body bgcolor="009900">
  <h3 align="center">User-Defined Function and Call</h3>
  <p align="center"><font size="+1">
  <?php
    // Function definition
    function welcome() {   
      $place = "San Francisco Zoo"; //Local variable
      print ("<b>Welcome to the $place!<br />");
    }
    
    // Function call
    welcome();  
  ?>
  </font></p>
 </body>
</html>
