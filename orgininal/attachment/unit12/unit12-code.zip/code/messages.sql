create TABLE messages
( id INT NOT NULL AUTO_INCREMENT
, subject VARCHAR(150)
, body TEXT
, PRIMARY KEY(id)
);
