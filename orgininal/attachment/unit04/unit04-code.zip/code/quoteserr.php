<?php
  $business = 'Joe's Pizza';
  print $business;
?>
