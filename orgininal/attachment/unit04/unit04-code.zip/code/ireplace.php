<html>
 <head>
  <title>The str_ireplace() Function</title>
 </head>
 <body bgcolor="lavender">
  <font size="+1">
  <h3>Case Insensitive Search and Replace</h3>
  <?php
    $text = 'Icecream is good for you. You should eat icecream
             daily.';
    $modified_text = str_ireplace('icecream','broccoli', $text );
    print 'original: '. $text .'<br />';
    // Not exactly what we want
    print 'modified: '. $modified_text .'<br />';
    // Capitalize the first character
    print 'capitalized: '. ucfirst($modified_text) .'<br />';
  ?>
 </body>
</html>
