<?php
  printf( "Value of Pi to 2 decimals is %.2f <br />\n", M_PI );
  printf( "Value of Pi to 4 decimals is %.4f <br />\n", M_PI );
?>
