<html>
 <head>
  <title>The str_pad() Function</title>
 </head>
 <body bgcolor="lavender">
  <font size="+1">
  <h3>Padding a String</h3>
  <?php
    $name="Elvis Presley";
    $prof="Singer";
    echo '<pre><b>', str_pad("Name:", 15) . $name,"\n" ;
    echo str_pad("Profession:", 15) . $prof,"\n\n" ;

    $string="Table of Contents";
    echo str_pad($string, 25, "-=", STR_PAD_BOTH),
         "\n</b></pre>";
  ?>
 </body>
</html>
