<html>
 <head>
  <title>Equal and Identical Strings</title>
 </head>
 <body bgcolor="lavender">
  <font size="+1">
  <h3>The == and === Operator</h3>
  <?php
    $str1 = "hello";
    $str2 = "hello";
    $str3 = 0;

    if ( $str1 == $str2 ){
      // They are equal
      print "\"$str1\" and \"$str2\" are equal.<br />";
    }
    else{
      print "\"$str1\" and \"$str2\" are not equal.<br />";
    }

    if ( $str2 == $str3 ){
      print "\"$str2\" and $str3 are equal.<br />";
    }
    else{
      print "\"$str2\" and $str3 are not equal.<br />";
    }

    if ($str2 === $str3){
      print "\"$str2\" and $str3 are identical.<br />";
    }
    else{
      print "\"$str2\" and $str3 are not identical.<br />";
    }
  ?>
 </body>
</html>
