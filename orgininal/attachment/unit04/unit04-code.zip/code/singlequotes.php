<?php
  print '<br />His salary was $50,000<br />';
  $salary=50000 * 1.1;
  print 'After his raise his salary is $salary\n';
?>
