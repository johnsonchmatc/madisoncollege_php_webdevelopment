<html>
 <head>
  <title>Text that is Similar</title>
 </head>
 <body bgcolor="silver">
  <font size="+1">
  <?php
    $string1 = "Once upon a time, there were three little pigs...";
    $string2 = "Once upon a time, there were three bears...";
    print "First string: $string1<br />";
    print "Second string: $string2<br />";
    $number = similar_text("$string1","$string2", $percent);
    print "There are $number of the same characters "
         ."in the two strings.<br />";
    echo "The strings are similar by: ". number_format($percent, 0)
        ."%<br />";
  ?>
  </font>
 </body>
</html>
