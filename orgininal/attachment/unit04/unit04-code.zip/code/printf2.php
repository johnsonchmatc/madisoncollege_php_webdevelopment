<?php
  $product_name = "Black shoes";
  $product_price = 249.95;
  printf("Product %s will cost %6.2f dollars",
         $product_name, $product_price );
?>
