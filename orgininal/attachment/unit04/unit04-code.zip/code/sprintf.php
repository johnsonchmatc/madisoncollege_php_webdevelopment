<?php
  $product_name = "Purple Dress";
  $product_price = 199.95;
  $output = sprintf("Product: <b>%s</b> will cost $<u>%6.2f</u> +
                     tax", $product_name, $product_price);
?>
<html>
 <head><title>The sprintf() Function</title></head>
 <body bgcolor="#EBF4F3">
  <h1>Shopping Cart Checkout</h1>
  <font face="Arial">
  <?= $output ?>
  </font>
 </body>
</html>
