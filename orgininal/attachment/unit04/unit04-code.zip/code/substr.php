<html>
 <head>
  <title>The substr() Function</title>
 </head>
 <body bgcolor="lavender">
  <font size="+1">
  <h3>Extracting Substrings</h3>
  <?php
    print '<b>substr("Happy New Year", 6)</b> produces: <em>';
    print substr("Happy New Year", 6) ."</em><br />";

    print '<b>substr("Happy New Year", 6, 3)</b> produces: <em>';
    print substr("Happy New Year", 6, 3) ."</em><br />";

    print '<b>substr("Happy New Year", -4)</b> produces: <em>';
    print substr("Happy New Year", -4) ."</em><br />";

    print '<b>substr("Happy New Year", -4, -1)</b> produces: <em>';
    print substr("Happy New Year", -4, -1) ."</em><br />";

    print '<b>substr("Happy New Year", 6, -2)</b> produces: <em>';
    print substr("Happy New Year", 6, -2) ."</em><br />";
  ?>
 </body>
</html>
