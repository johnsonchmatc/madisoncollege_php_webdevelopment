<html>
 <head>
  <title>Finding the Length of a String</title>
 </head>
 <body bgcolor="lightgreen">
  <font size="+1">
  <?php
    $string="\t\tHello, world.";
    $length=strlen($string);
    print "There are $length characters in \"$string\"";
  ?>
 </body>
</html>
